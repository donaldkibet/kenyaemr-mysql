-- Create ETL schemas that the module expects
CREATE DATABASE IF NOT EXISTS kenyaemr_etl DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
CREATE DATABASE IF NOT EXISTS kenyaemr_datatools DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
CREATE DATABASE IF NOT EXISTS dwapi_etl DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;

-- Grant the OpenMRS DB user access to those schemas
GRANT ALL PRIVILEGES ON kenyaemr_etl.* TO 'openmrs'@'%';
GRANT ALL PRIVILEGES ON kenyaemr_datatools.* TO 'openmrs'@'%';
GRANT ALL PRIVILEGES ON dwapi_etl.* TO 'openmrs'@'%';
FLUSH PRIVILEGES;

use openmrs;
delete from liquibasechangelog where id like '%charts%';
-- Grant SYSTEM_USER privilege for MySQL 8+ (required for DROP PROCEDURE operations)
GRANT SYSTEM_USER ON *.* TO 'openmrs'@'%';
FLUSH PRIVILEGES;